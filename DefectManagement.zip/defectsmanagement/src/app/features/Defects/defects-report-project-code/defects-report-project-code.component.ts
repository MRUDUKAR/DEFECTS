import { Component } from '@angular/core';
import { Defect } from '../models/defect.model';
import { DefectService } from '../services/defect.service';

@Component({
  selector: 'app-defects-report-project-code',
  templateUrl: './defects-report-project-code.component.html',
  styleUrl: './defects-report-project-code.component.css'
})
export class DefectsReportProjectCodeComponent {

  projectcode1 : number =0;
  defects: Defect[];
  a:number=0;
  
  constructor(private defectService:DefectService){

  }
  onSubmit(){
    console.log(this.projectcode1);
    this.defectService.defectsReportByProjectCode(this.projectcode1)
    .subscribe(
      (response) => {
        console.log(response);
       this.defects= response;
       if(this.defects.length!=0){
        this.a=1;
       }
       else{
        this.a=2;
       }
       
      },
      (error) => {
        console.error('Error Fetching Defect Details:', error);
      }
    );
  }

}
