import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefectsReportProjectCodeComponent } from './defects-report-project-code.component';

describe('DefectsReportProjectCodeComponent', () => {
  let component: DefectsReportProjectCodeComponent;
  let fixture: ComponentFixture<DefectsReportProjectCodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DefectsReportProjectCodeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DefectsReportProjectCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
