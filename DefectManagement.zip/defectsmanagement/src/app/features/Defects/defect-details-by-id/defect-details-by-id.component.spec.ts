import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefectDetailsByIdComponent } from './defect-details-by-id.component';

describe('DefectDetailsByIdComponent', () => {
  let component: DefectDetailsByIdComponent;
  let fixture: ComponentFixture<DefectDetailsByIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DefectDetailsByIdComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DefectDetailsByIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
