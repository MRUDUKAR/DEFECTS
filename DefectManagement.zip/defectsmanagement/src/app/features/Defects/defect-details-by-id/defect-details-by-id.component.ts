import { Component } from '@angular/core';
import { Defect } from '../models/defect.model';
import { DefectService } from '../services/defect.service';

@Component({
  selector: 'app-defect-details-by-id',
  templateUrl: './defect-details-by-id.component.html',
  styleUrl: './defect-details-by-id.component.css'
})
export class DefectDetailsByIdComponent {

  defectId1:number=0;
  defects : Defect;
  a:number=0;

  constructor(private defectService:DefectService){}

onSubmit(){
  console.log(this.defectId1);
  this.defectService.defectDetails(this.defectId1)
  .subscribe(
    (response) => {
      console.log(response);
     this.defects= response;
     this.a=1;
    },
    (error) => {
      console.error('Error Fetching Defect Details:', error);
      this.a=2;
    }
  );
}
}
