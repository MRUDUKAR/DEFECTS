import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefectReportDeveloperIdComponent } from './defect-report-developer-id.component';

describe('DefectReportDeveloperIdComponent', () => {
  let component: DefectReportDeveloperIdComponent;
  let fixture: ComponentFixture<DefectReportDeveloperIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DefectReportDeveloperIdComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DefectReportDeveloperIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
