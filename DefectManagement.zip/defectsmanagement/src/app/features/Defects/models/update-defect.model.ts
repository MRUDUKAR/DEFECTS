export interface UpdateDefect{
    status1:string;
}