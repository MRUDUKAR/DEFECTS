import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AddDefectRequest } from '../models/add-defect-request.model';
import { Defect } from '../models/defect.model';
import { UpdateDefect } from '../models/update-defect.model';

@Injectable({
  providedIn: 'root'
})
export class DefectService {

  constructor(private http: HttpClient) { }

  
  addDefect(model: AddDefectRequest) : Observable<void> {
    return this.http.post<void>(`https://localhost:7238/api/demo1/new`,model);
  }
   
  defectDetails(defectid: number): Observable<Defect>{
    return this.http.get<Defect>(`https://localhost:7238/api/demo1/${defectid}`);

  }

  defectsReportByDeveloperId(developerId: string): Observable<Defect[]> {
    return this.http.get<Defect[]>(`https://localhost:7238/api/demo1/assignedto/${developerId}`);
  }

  defectsReportByProjectCode(projectcode: number): Observable<Defect[]> {
    return this.http.get<Defect[]>(`https://localhost:7238/api/demo1/report/${projectcode}`);
}

updatestatus(status1:UpdateDefect,id:number) : Observable<boolean>{
  return this.http.put<boolean>(`https://localhost:7238/api/demo1/resolve/${id}`,status1);
}
}
