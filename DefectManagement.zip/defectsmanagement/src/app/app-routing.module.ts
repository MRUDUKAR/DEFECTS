import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddDefectComponent } from './features/Defects/add-defect/add-defect.component';
import { BackComponent } from './features/Defects/back/back.component';
import { DefectDetailsByIdComponent } from './features/Defects/defect-details-by-id/defect-details-by-id.component';
import { DefectReportDeveloperIdComponent } from './features/Defects/defect-report-developer-id/defect-report-developer-id.component';
import { DefectsReportProjectCodeComponent } from './features/Defects/defects-report-project-code/defects-report-project-code.component';
import { UpdateDefectsComponent } from './features/Defects/update-defects/update-defects.component';

const routes: Routes = [
  {path:'Defects/AddDefects',component:AddDefectComponent},
  {path:'Defects/DefectDetails',component:DefectDetailsByIdComponent},
  {path:'Defects/DefectsReport/DeveloperId',component:DefectReportDeveloperIdComponent},
  {path:'Defects/DefectsReport/ProjectCode',component:DefectsReportProjectCodeComponent},
  {path:'updateDefects/:defectId1',component:UpdateDefectsComponent},
  {path:'Defects/Home',component:BackComponent},
  {path:'',redirectTo:'Defects/Home',pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
