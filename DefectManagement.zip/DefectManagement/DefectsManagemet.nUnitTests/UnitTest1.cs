using AutoMapper;
using DefectManagement_DAL.Models;
using DefectManagement1_BAL.DemoDTO;
using DefectManagement1_BAL.Mappers;
using DefectManagement1_BAL.Services;
using DefectManagement1_DAL.Models;
using DefectManagement1_DAL.Repository;
using Moq;
using NUnit.Framework.Internal;
namespace DefectsManagemet.nUnitTests
{
    [TestFixture]
    public class DefectManagementTests
    {
        private Mock<IDemoRepository> _defectsRepositoryMock;
        private DemoServiceClass _demoServiceClass;
        private Mock<IMapper> _mapper;
        [SetUp]
        public void Setup()
        {
            _defectsRepositoryMock = new Mock<IDemoRepository>();
            _mapper = new Mock<IMapper>();
            _demoServiceClass = new DemoServiceClass(_defectsRepositoryMock.Object, _mapper.Object);
        }

        [Test]
        //Adding Test Cases
        public void AddDefect_ValidateDefect_ReturnsTrue()
        {
            //Arrange
            var validDefectDTO = new DemoDefectDTO
            {

                Title1 = "Title",
                DefectDetails1 = "The defect details must be atleast ten words for valid column",
                StepsToReproduce1 = "Steps to Reproduce must be atleast ten words for valid column",
                Priority1 = DefectManagement_DAL.Models.Defect1.Priority1_value.P1,
                ReportedByTesterId1 = "CTS101",
                AssignedToDeveloperId1 = "CTS201",
                Severity1 = DefectManagement_DAL.Models.Defect1.Severity1_value.blocker,
                Status1 = "Pending",
                ProjectCode1 = 34
            };

            _defectsRepositoryMock.Setup(r => r.AddNewDemoDefect(It.IsAny<Defect1>())).Returns(true);


            //Act
            var result = _demoServiceClass.AddNewDemoDefect(validDefectDTO);

            //Assert
            Assert.NotNull(result);
            Assert.IsTrue(result);


        }

        [Test]
        //2
        public void AddDefect_InvalidDefect_ReturnsFalse()
        {
            //Arrange
            var invalidDefectDTO = new DemoDefectDTO
            {

                Title1 = "",
                DefectDetails1 = "The defect details must be atleast ten words for valid column",
                StepsToReproduce1 = "Steps to Reproduce must be atleast ten words for valid column",
                Priority1 = DefectManagement_DAL.Models.Defect1.Priority1_value.P1,
                ReportedByTesterId1 = "CTS101",
                AssignedToDeveloperId1 = "CTS201",
                Severity1 = DefectManagement_DAL.Models.Defect1.Severity1_value.blocker,
                Status1 = "Pending",
                ProjectCode1 = 22
            };

            _defectsRepositoryMock.Setup(r => r.AddNewDemoDefect(It.IsAny<Defect1>())).Returns(false);

            //Act
            var result = _demoServiceClass.AddNewDemoDefect(invalidDefectDTO);

            Assert.NotNull(result);
            Assert.IsFalse(result);
        }

        [Test]
        //3
        //Updating
        public void UpdateDefect_Should_Update_Defect_Status()
        {
            // Arrange
            var demoupdateDefectDTO = new DemoUpdateDefectDTO { Status1 = "Resolved" };
            var id = 53; // Example defect ID

            // Act
            _defectsRepositoryMock.Setup(m => m.UpdateDemoDefect(It.IsAny<Defect1>(), id)).Returns(true);


            var result = _demoServiceClass.UpdateDemoDefectWithResolution(demoupdateDefectDTO, id);

            // Assert

            Assert.IsTrue(result, "Update should succeed");
            _defectsRepositoryMock.Verify(repo => repo.UpdateDemoDefect(It.IsAny<Defect1>(), id), Times.Once);


        }


        [Test]
        //4
        public void UpdateDefect_Should_Throws_error()
        {   //Arrange
            var demoupdateDefectDTO = new DemoUpdateDefectDTO { Status1 = "Resolved" };
            var id = 42; // Example defect ID

            // Set up repository mock to throw an exception

            _defectsRepositoryMock.Setup(repo => repo.UpdateDemoDefect(It.IsAny<Defect1>(), id))
                .Throws(new Exception("Update not successful"));

            // Act and Assert
            Assert.Throws<Exception>(() => _demoServiceClass.UpdateDemoDefectWithResolution(demoupdateDefectDTO, id));
        }


        [Test]
        //5
        //Get Details By Id
        public void GetDefectById_Should_Return_DefectDetailsDTO()
        {
            // Arrange
            var Id = 24; // Example defect ID
            var defectFromRepository = new Defect1
            {
                DefectId1 = Id,
                Title1 = "Login Button Not Functional",
                DefectDetails1 = "Clicking on the login button deoesn't redirect users to the login page",
                StepsToReproduce1 = "open to application and click on the login button and notice that no action is taken",
                Priority1 = DefectManagement_DAL.Models.Defect1.Priority1_value.P1,
                DefectedOn1 = new DateOnly(2024, 03, 22),
                ExpectedResolution1 = new DateOnly(2024, 03, 24),
                ReportedByTesterId1 = "CTS101",
                AssignedToDeveloperId1 = "CTS201",
                Severity1 = DefectManagement_DAL.Models.Defect1.Severity1_value.blocker,
                Status1 = "Resolved",
                ProjectCode1 = 21

            };

            _defectsRepositoryMock.Setup(repo => repo.GetDemoDefectById(Id)).Returns(defectFromRepository);

            // Act
            var result = _demoServiceClass.GetDemoDefectById(Id);

            // Assert
            Assert.NotNull(result);
            Assert.AreEqual(Id, result.DefectId1);
            Assert.AreEqual("Login Button Not Functional", result.Title1);

        }

        [Test]
        //6
        public void GetDefectById_Should_Throw_Exception_On_Failure()
        {
            // Arrange
            var defectId = 42; // Example defect ID

            // Set up repository mock to throw an exception
            _defectsRepositoryMock.Setup(repo => repo.GetDemoDefectById(defectId))
                .Throws(new Exception("It Returns Error"));

            // Act and Assert
            Assert.Throws<Exception>(() => _demoServiceClass.GetDemoDefectById(defectId));
        }

        [Test]
        //7
        public void GetDefectById_Should_Return_DefectDetailsDTO_Null()
        {
            // Arrange
            var Id = 42; // Example defect ID


            // Set up repository mock to return unexpected values
            _defectsRepositoryMock.Setup(repo => repo.GetDemoDefectById(Id))
                .Returns(new Defect1()); // Return an empty defect

            // Act
            var result = _demoServiceClass.GetDemoDefectById(Id);

            // Assert
            Assert.NotNull(result);
            Assert.AreNotEqual(54, result.DefectId1); // Expecting a different ID
            Assert.AreNotEqual("Critical Bug", result.Title1);
        }

        //8
        [Test]
        //GEt report by developer Id
        public void GetDefectsAssignedToDeveloper_Should_ReturnListOfDefectDTOs()
        {
            // Arrange
            string developerId = "CTS201"; // Replace with an actual developer ID
            var defectsFromRepository = new List<Defect1>
            {
                new Defect1
                {
                DefectId1 = 1,
                Title1 = "Login Button Not Functional",
                DefectDetails1 = "Clicking on the login button deoesn't redirect users to the login page",
                StepsToReproduce1 = "open to application and click on the login button and notice that no action is taken",
                Priority1 = DefectManagement_DAL.Models.Defect1.Priority1_value.P1,
                DefectedOn1 = new DateOnly(2024, 03, 22),
                ExpectedResolution1 = new DateOnly(2024, 03, 24),
                ReportedByTesterId1 = "CTS101",
                AssignedToDeveloperId1 = developerId,
                Severity1 = DefectManagement_DAL.Models.Defect1.Severity1_value.blocker,
                Status1 = "Resolved",
                ProjectCode1 = 21

                },
                new Defect1
                {
                DefectId1 = 2,
                Title1 = "Login Button Not Functional",
                DefectDetails1 = "Clicking on the login button deoesn't redirect users to the login page",
                StepsToReproduce1 = "open to application and click on the login button and notice that no action is taken",
                Priority1 = DefectManagement_DAL.Models.Defect1.Priority1_value.P1,
                DefectedOn1 = new DateOnly(2024, 03, 22),
                ExpectedResolution1 = new DateOnly(2024, 03, 24),
                ReportedByTesterId1 = "CTS101",
                AssignedToDeveloperId1 = developerId,
                Severity1 = DefectManagement_DAL.Models.Defect1.Severity1_value.blocker,
                Status1 = "Resolved",
                ProjectCode1 = 21
                }
            };

            var expectedDefectDTOs = new List<DemoDefectDTOs>
            {
                new DemoDefectDTOs
                {
                 DefectId1 = 1,
                Title1 = "Login Button Not Functional",
                DefectDetails1 = "Clicking on the login button deoesn't redirect users to the login page",
                StepsToReproduce1 = "open to application and click on the login button and notice that no action is taken",
                Priority1 = DefectManagement_DAL.Models.Defect1.Priority1_value.P1,
                DefectedOn1 = new DateOnly(2024, 03, 22),
                ExpectedResolution1 = new DateOnly(2024, 03, 24),
                ReportedByTesterId1 = "CTS101",
                AssignedToDeveloperId1 = developerId,
                Severity1 = DefectManagement_DAL.Models.Defect1.Severity1_value.blocker,
                Status1 = "Resolved",
                ProjectCode1 = 21
                },
                new DemoDefectDTOs
                {
                 DefectId1 = 2,
                Title1 = "Login Button Not Functional",
                DefectDetails1 = "Clicking on the login button deoesn't redirect users to the login page",
                StepsToReproduce1 = "open to application and click on the login button and notice that no action is taken",
                Priority1 = DefectManagement_DAL.Models.Defect1.Priority1_value.P1,
                DefectedOn1 = new DateOnly(2024, 03, 22),
                ExpectedResolution1 = new DateOnly(2024, 03, 24),
                ReportedByTesterId1 = "CTS101",
                AssignedToDeveloperId1 = developerId,
                Severity1 = DefectManagement_DAL.Models.Defect1.Severity1_value.blocker,
                Status1 = "Resolved",
                ProjectCode1 = 21
                }
            };

            _defectsRepositoryMock.Setup(repo => repo.GetDemoDefectAssignToDeveloper(developerId))
                .Returns(defectsFromRepository);

            foreach (var defect in defectsFromRepository)
            {
                _mapper.Setup(mapper => mapper.Map<DemoDefectDTOs>(defect))
                    .Returns(expectedDefectDTOs.Find(dto => dto.DefectId1 == defect.DefectId1));
            }

            // Act
            var result = _demoServiceClass.GetDemoDefectAssignToDeveloper(developerId);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(expectedDefectDTOs.Count, result.Count);
        }

        [Test]
        //9
        public void GetDefectsAssignedToDeveloper_WhenExceptionThrown_Should_HandleException()
        {
            // Arrange
            string developerId = "CTS201";
            _defectsRepositoryMock.Setup(repo => repo.GetDemoDefectAssignToDeveloper(developerId))
                .Throws(new InvalidOperationException("It Throws Exception"));

            // Act and Assert
            Assert.Throws<InvalidOperationException>(() => _demoServiceClass.GetDemoDefectAssignToDeveloper(developerId));
        }

        [Test]
        //Get report by project code
        //10
        public void GetDefects_In_Should_ReturnListOfDefectDTOs()
        {
            // Arrange
            int projectcode = 22; // Replace with an actual developer ID
            var defectsFromRepository = new List<Defect1>
            {
                new Defect1
                {

                DefectId1 = 1,
                Title1 = "Login Button Not Functional",
                DefectDetails1 = "Clicking on the login button deoesn't redirect users to the login page",
                StepsToReproduce1 = "open to application and click on the login button and notice that no action is taken",
                Priority1 = DefectManagement_DAL.Models.Defect1.Priority1_value.P1,
                DefectedOn1 = new DateOnly(2024, 03, 22),
                ExpectedResolution1 = new DateOnly(2024, 03, 24),
                ReportedByTesterId1 = "CTS101",
                AssignedToDeveloperId1 = "CTS201",
                Severity1 = DefectManagement_DAL.Models.Defect1.Severity1_value.blocker,
                Status1 = "Resolved",
                ProjectCode1 = projectcode

                },
                new Defect1
                {
                DefectId1 = 2,
                Title1 = "Login Button Not Functional",
                DefectDetails1 = "Clicking on the login button deoesn't redirect users to the login page",
                StepsToReproduce1 = "open to application and click on the login button and notice that no action is taken",
                Priority1 = DefectManagement_DAL.Models.Defect1.Priority1_value.P1,
                DefectedOn1 = new DateOnly(2024, 03, 22),
                ExpectedResolution1 = new DateOnly(2024, 03, 24),
                ReportedByTesterId1 = "CTS101",
                AssignedToDeveloperId1 = "CTS201",
                Severity1 = DefectManagement_DAL.Models.Defect1.Severity1_value.blocker,
                Status1 = "Resolved",
                ProjectCode1 = projectcode
                }
            };

            var expectedDefectDTOs = new List<DemoDefectDTOs>
            {
                new DemoDefectDTOs
                {
                DefectId1 = 1,
                Title1 = "Login Button Not Functional",
                DefectDetails1 = "Clicking on the login button deoesn't redirect users to the login page",
                StepsToReproduce1 = "open to application and click on the login button and notice that no action is taken",
                Priority1 = DefectManagement_DAL.Models.Defect1.Priority1_value.P1,
                DefectedOn1 = new DateOnly(2024, 03, 22),
                ExpectedResolution1 = new DateOnly(2024, 03, 24),
                ReportedByTesterId1 = "CTS101",
                AssignedToDeveloperId1 = "CTS201",
                Severity1 = DefectManagement_DAL.Models.Defect1.Severity1_value.blocker,
                Status1 = "Resolved",
                ProjectCode1 = projectcode
                },
                new DemoDefectDTOs
                {
                DefectId1 = 2,
                Title1 = "Login Button Not Functional",
                DefectDetails1 = "Clicking on the login button deoesn't redirect users to the login page",
                StepsToReproduce1 = "open to application and click on the login button and notice that no action is taken",
                Priority1 = DefectManagement_DAL.Models.Defect1.Priority1_value.P1,
                DefectedOn1 = new DateOnly(2024, 03, 22),
                ExpectedResolution1 = new DateOnly(2024, 03, 24),
                ReportedByTesterId1 = "CTS101",
                AssignedToDeveloperId1 = "CTS201",
                Severity1 = DefectManagement_DAL.Models.Defect1.Severity1_value.blocker,
                Status1 = "Resolved",
                ProjectCode1 = projectcode
                }
            };

            _defectsRepositoryMock.Setup(repo => repo.GetDemoDefectReport(projectcode))
                .Returns(defectsFromRepository);

            foreach (var defect in defectsFromRepository)
            {
                _mapper.Setup(mapper => mapper.Map<DemoDefectDTOs>(defect))
                    .Returns(expectedDefectDTOs.Find(dto => dto.DefectId1 == defect.DefectId1));
            }

            // Act
            var result = _demoServiceClass.GetDemoDefectReport(projectcode);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(expectedDefectDTOs.Count, result.Count);

        }

        [Test]
        //11
        public void GetDefectsByProjectCode_WhenExceptionThrown_Should_HandleException()
        {
            // Arrange
            int projectcode = 22;
            _defectsRepositoryMock.Setup(repo => repo.GetDemoDefectReport(projectcode))
                .Throws(new InvalidOperationException("It Throws Exception"));

            // Act and Assert
            Assert.Throws<InvalidOperationException>(() => _demoServiceClass.GetDemoDefectReport(projectcode));
        }


    }
}