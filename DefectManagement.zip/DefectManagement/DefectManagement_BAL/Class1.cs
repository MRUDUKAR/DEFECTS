﻿namespace DefectManagement_BAL
{
    public class Class1
    {

    }
}
