﻿using DefectManagement1_BAL.DemoDTO;
using DefectManagement1_BAL.Services;
using DefectManagement1_DAL.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;
using log4net;

namespace DefectManagement1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class demo1Controller : ControllerBase
    {
        private readonly IDemoServiceClass _demoService;
        private readonly ILog _logger;

        public demo1Controller(IDemoServiceClass demoService,ILog logger)
        {
            _demoService = demoService;
            _logger = logger;
        }

        [HttpPost]
        [Route("new")]
        public IActionResult AddNewDemoDefect([FromBody] DemoDefectDTO defectDTO)
        {
            try
            {
                var result = _demoService.AddNewDemoDefect(defectDTO);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                return StatusCode(500, ex.Message);
            }

        }

        [HttpGet]
        [Route("assignedto/{developerid}")]
        public IActionResult GetDemoDefectsAssignedToDeveloper(string developerid)
        {
            try
            {
                var defects = _demoService.GetDemoDefectAssignToDeveloper(developerid);
                if (defects == null)
                {
                    return BadRequest("No Defects are assigned to this Developer");
                }
                return Ok(defects);

            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet]
        [Route("{defectid}")]
        public IActionResult GetDemoDefectDetailsById(int defectid)
        {
            try
            {
                var defectDetails = _demoService.GetDemoDefectById (defectid);
                if (defectDetails == null)
                {
                    return BadRequest("No Defects are there by with this id");
                }
                return Ok(defectDetails);
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                return StatusCode(500, ex.Message);
            }
        }


        [HttpPut]
        [Route("resolve/{id}")]
        public IActionResult UpdateDemoDefectsWithResolution([FromBody] DemoUpdateDefectDTO updateDefectDTO, int id)
        {

            try
            {
                var result = _demoService.UpdateDemoDefectWithResolution(updateDefectDTO, id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                return StatusCode(500, ex.Message);
            }

        }


        [HttpGet]
        [Route("report/{projectcode}")]
        public IActionResult GetDemoDefectsReportByProjectCode(int projectcode)
        {
            try
            {
                var defectDetails = _demoService.GetDemoDefectReport(projectcode);
                if (defectDetails == null)
                {
                    return BadRequest("No Defects are there by in this project");
                }
                return Ok(defectDetails);
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                return StatusCode(500, ex.Message);
            }
        }

    }
}
