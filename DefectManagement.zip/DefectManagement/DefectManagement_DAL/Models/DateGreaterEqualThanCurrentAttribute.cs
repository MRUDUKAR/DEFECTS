﻿using DefectManagement_DAL.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

namespace DefectManagement1_DAL.Models
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter)]
    public class DateGreaterEqualThanCurrentAttribute : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            var defect = (Defect1)validationContext.ObjectInstance;
            if (defect.ExpectedResolution1 >= defect.DefectedOn1) return ValidationResult.Success;
            return new ValidationResult(this.ErrorMessage);
        }

    }
}
