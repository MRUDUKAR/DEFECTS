﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DefectManagement1_DAL.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Defect1s",
                columns: table => new
                {
                    DefectId1 = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    DefectDeatils1 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    StepsToReproduce1 = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                    Priority1 = table.Column<string>(type: "nvarchar(2)", maxLength: 2, nullable: false),
                    DefectedOn1 = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ExpectedResolution1 = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ReportedByTesterId1 = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: false),
                    AssignedToDeveloperId1 = table.Column<string>(type: "nvarchar(6)", maxLength: 6, nullable: false),
                    Severity1 = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Status1 = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    ProjectCode1 = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Defect1s", x => x.DefectId1);
                });

            migrationBuilder.CreateTable(
                name: "Resolutions1s",
                columns: table => new
                {
                    ResolutionId1 = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DefectId1 = table.Column<int>(type: "int", nullable: false),
                    ResolutionDate1 = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Resolution1 = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Resolutions1s", x => x.ResolutionId1);
                    table.ForeignKey(
                        name: "FK_Resolutions1s_Defect1s_DefectId1",
                        column: x => x.DefectId1,
                        principalTable: "Defect1s",
                        principalColumn: "DefectId1",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Resolutions1s_DefectId1",
                table: "Resolutions1s",
                column: "DefectId1");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Resolutions1s");

            migrationBuilder.DropTable(
                name: "Defect1s");
        }
    }
}
